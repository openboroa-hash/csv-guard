import { createReadStream } from 'node:fs';
import { lstat, realpath } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, normalize, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const securityHeaders = {
  'Content-Security-Policy': "default-src 'self'; connect-src 'none'; img-src 'self' data:; style-src 'self'; script-src 'self'; worker-src 'none'; child-src 'none'; frame-src 'none'; frame-ancestors 'none'; object-src 'none'; media-src 'none'; manifest-src 'none'; base-uri 'none'; form-action 'none'",
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
};

const types = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.md', 'text/markdown; charset=utf-8'],
  ['.svg', 'image/svg+xml'],
]);

function safePath(url, root) {
  let pathname;
  try { pathname = decodeURIComponent(new URL(url, 'http://localhost').pathname); }
  catch { return null; }
  if (pathname.includes('\\') || pathname.includes('\0')) return null;
  const requested = pathname === '/' ? 'index.html' : pathname.slice(1);
  const absolute = resolve(root, normalize(requested));
  const fromRoot = relative(root, absolute);
  if (!fromRoot || fromRoot === '..' || fromRoot.startsWith('..' + sep)) return null;
  return absolute;
}

export async function createLocalServer({ root = fileURLToPath(new URL('./', import.meta.url)) } = {}) {
  const canonicalRoot = await realpath(root);
  return createServer(async (request, response) => {
    if (!['GET', 'HEAD'].includes(request.method || '')) {
      response.writeHead(405, { ...securityHeaders, Allow: 'GET, HEAD' }).end();
      return;
    }
    const path = safePath(request.url || '/', root);
    try {
      if (!path) throw new Error('not found');
      const canonicalPath = await realpath(path);
      const fromCanonicalRoot = relative(canonicalRoot, canonicalPath);
      if (!fromCanonicalRoot || fromCanonicalRoot === '..' || fromCanonicalRoot.startsWith('..' + sep)) {
        throw new Error('not found');
      }
      const stat = await lstat(path);
      if (stat.isSymbolicLink() || !stat.isFile()) throw new Error('not found');
      const headers = {
        'Cache-Control': 'no-store',
        'Content-Type': types.get(extname(path).toLowerCase()) || 'application/octet-stream',
        ...securityHeaders,
      };
      if (request.method === 'HEAD') {
        response.writeHead(200, { ...headers, 'Content-Length': stat.size }).end();
        return;
      }
      response.writeHead(200, headers);
      createReadStream(path).on('error', () => response.destroy()).pipe(response);
    } catch {
      response.writeHead(404, { ...securityHeaders, 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }).end('No encontrado');
    }
  });
}

const isMain = process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url;
if (isMain) {
  const host = '127.0.0.1';
  const port = 4173;
  const server = await createLocalServer();
  server.listen(port, host, () => {
    console.log('CSV Guard disponible en http://' + host + ':' + port);
    console.log('Pulsa Ctrl+C para detenerlo.');
  });
}
