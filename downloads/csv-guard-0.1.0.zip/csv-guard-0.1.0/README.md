# CSV Guard — uso local

Prototipo web estático para detectar riesgos frecuentes antes de importar un CSV. El análisis ocurre en la memoria del navegador; el candidato no incluye backend, telemetría ni almacenamiento persistente.

## Abrir de forma segura

1. Conserva completa esta carpeta; no separes ni renombres sus archivos internos.
2. Con Node 22–24, abre una terminal dentro de esta carpeta y ejecuta `node serve-local.mjs`. El servidor incluido solo escucha en `127.0.0.1:4173`, no lista carpetas y no admite escritura.
3. Abre `http://127.0.0.1:4173` en el navegador.
4. No abras `index.html` mediante `file://`: algunos navegadores bloquean así módulos o recursos locales.
5. Detén el servidor con Ctrl+C al terminar.

Si el puerto 4173 está ocupado o no dispones de Node, usa un servidor HTTP estático de confianza enlazado exclusivamente a `127.0.0.1`. No expongas la carpeta en `0.0.0.0` ni en una interfaz de red.

## Uso

- «Usar ejemplo sintético» permite probar la interfaz sin archivos propios.
- El selector admite archivos `.csv` de hasta 5 MiB.
- Los filtros muestran todas las incidencias o solo errores, advertencias o información.
- CSV Guard informa riesgos; no corrige ni modifica el archivo original.

## Integridad y procedencia

Este archivo pertenece a la carpeta versionada `csv-guard-0.1.0`. El manifiesto adjunto `csv-guard-0.1.0.SHA256SUMS.txt` permite detectar cambios accidentales, pero SHA-256 no demuestra quién creó el paquete porque no existe firma.

No se ha publicado ni firmado ningún paquete oficial. El código propio se ofrece bajo la licencia MIT incluida en `LICENSE`; cualquier copia o redistribución debe conservarla. `THIRD_PARTY_NOTICES.md` contiene el aviso obligatorio de componentes de terceros y también debe permanecer en el paquete.

## Actualización, reversión y retirada

- Para actualizar, conserva primero esta carpeta y prueba la nueva versión por separado; no mezcles archivos de versiones distintas.
- Para revertir, detén el servidor y vuelve a servir la carpeta completa de la versión anterior.
- Para retirar CSV Guard, detén el servidor y elimina esta carpeta.

No hay migración ni borrado adicional: CSV Guard no guarda CSV, resultados, cookies ni configuración. Los archivos originales no se modifican.

## Limitaciones conocidas

- Solo se admite la coma como delimitador.
- El parser cubre los casos probados, no todas las variantes CSV posibles.
- No hay instalador, actualización automática, firma, soporte comercial ni garantía de compatibilidad universal.
- Antes de usar información sensible, valida por tu cuenta el entorno local y la ausencia de solicitudes externas en las herramientas de red del navegador.
